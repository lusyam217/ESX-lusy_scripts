fx_version 'cerulean'
game 'gta5'

author 'lusyam_217'
description 'Eliminar NPCs'

client_script "main.lua"